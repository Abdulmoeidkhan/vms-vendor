<div class="d-flex align-items-center gap-2">
    @if($userStatus)
    <span class="badge mx-auto  bg-success rounded-3 fw-semibold">Active</span>
    @else
    <span class="badge mx-auto  bg-badar rounded-3 fw-semibold">Inactive</span>
    @endif
</div>