@auth
@extends('layouts.layout')
@section("content")


<livewire:add-user-component />

<livewire:user-list-component />

@endsection
@endauth